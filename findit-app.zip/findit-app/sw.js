// FindIt service worker: keeps the app and its built-in libraries available offline.
// (The object-finder model is cached separately by transformers.js after its first download.)
const CACHE = "findit-v2";
const SHELL = [
  "./", "index.html", "app.js", "manifest.webmanifest", "icons/icon-192.png", "icons/icon-512.png",
  "vendor/transformers.min.js", "vendor/ort-wasm-simd-threaded.jsep.mjs", "vendor/ort-wasm-simd-threaded.jsep.wasm",
  "vendor/tesseract.min.js", "vendor/worker.min.js",
  "vendor/tesseract-core/tesseract-core-simd-lstm.wasm.js", "vendor/tesseract-core/tesseract-core-lstm.wasm.js",
  "lang/eng.traineddata",
];
self.addEventListener("install", (e) => { e.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener("activate", (e) => {
  e.waitUntil(caches.keys().then((ks) => Promise.all(ks.filter((k) => k.startsWith("findit-") && k !== CACHE).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (e.request.method !== "GET" || url.origin !== location.origin) return;     // models etc. go straight to the network
  e.respondWith(caches.match(e.request, { ignoreSearch: true }).then((hit) => hit || fetch(e.request).then((res) => {
    if (res.ok) { const copy = res.clone(); caches.open(CACHE).then((c) => c.put(e.request, copy)); }
    return res;
  })));
});
