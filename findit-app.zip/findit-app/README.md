# FindIt

Find things and read labels with your camera. FindIt is a web app that installs to a phone or computer and runs
**entirely on the device**: no account, no server, and photos never leave the device.

- **Find something:** keys, phone, glasses, or anything you name ("the book called Atomic Habits", "my Tylenol").
  It outlines the item on the photo and says where it is ("on the table, on the right, at about 2 o'clock, an arm's length away").
- **Read text:** medicine and food labels, books, letters and bills. Shows the text in large print and reads it aloud.
- **Read its label:** after Find, zooms in on the item to read small or faraway text.
- **Zooms in automatically:** when something isn't found in the whole photo, FindIt looks again at overlapping
  zoomed-in parts of the full-resolution photo: for small objects, for small print, and for sideways text such as
  book spines. It also zooms into each possible match (for example every book it sees) to read its title.
- **Checks up close:** tiny print often comes out garbled the first time. FindIt re-reads the spots that look most
  like the name, enlarged and in black and white, which lets it read titles on very thin spines.

## How it works

| Part | What it uses | Size | When it downloads |
|---|---|---|---|
| Text reader (OCR) | Tesseract.js 6.0.1 + English model | ~12 MB | Included in this folder |
| Object finder | OWL-ViT base (`Xenova/owlvit-base-patch32`) via Transformers.js 3.7.6 | ~150 MB | Once, from Hugging Face, the first time you tap "Download the object finder" |
| Speech out | The device's built-in voice | — | Built in |
| Speech in (🎤) | The browser's speech recognition, where available | — | Built in (Chrome sends audio to Google; Safari can run on-device) |

After the first download, everything works offline. The models run on the CPU (WebAssembly), or on the GPU (WebGPU)
when the browser supports it.

## Option 1: put it online so anyone can use it (recommended, needed for phones)

Phones only allow the camera on secure (https) web addresses, so for phone use the folder must be hosted. Either is free:

**Netlify Drop (2 minutes, no coding):**
1. Unzip this folder.
2. Go to https://app.netlify.com/drop and drag the whole `findit-app` folder onto the page.
3. You get a link like `https://something.netlify.app`. Share it.

**GitHub Pages:**
1. Create a new public repository and upload the contents of this folder.
2. In the repository: Settings → Pages → Source: "Deploy from a branch", branch `main`, folder `/ (root)`.
3. After a minute the app is at `https://<your-username>.github.io/<repository-name>/`.

**Installing on a phone:** open the link, tap **Download the object finder** once (use Wi-Fi), then:
- iPhone (Safari): Share → **Add to Home Screen**.
- Android (Chrome): menu ⋮ → **Install app** (or Add to Home screen).

It then opens like a normal app and works without internet.

## Option 2: run it on a computer

Needs Python 3 (already on most Macs; on Windows install from https://www.python.org, ticking "Add to PATH").

- **Mac:** double-click `Start FindIt (Mac).command`. The first time, macOS may block it: right-click → Open → Open.
- **Windows:** double-click `Start FindIt (Windows).bat`.

Your browser opens `http://localhost:8765`. Keep the small terminal window open while using FindIt. A webcam works
with **Use live camera**; you can also choose photos from the computer.

Opening `index.html` directly (double-clicking it) does **not** work: browsers block the camera and the AI models
for files opened that way.

## Tips

- Good light and a steady phone matter more than anything else.
- For small print, hold the phone close so the label fills most of the photo.
- For book spines, the app also reads sideways text, but spines must be facing the camera. Slanted text (books lying
  at an angle) is hard for it: turn the phone to line up with the text.
- Zooming in takes longer (often 10–60 seconds on a phone when it has to search every part). Progress is shown and announced.

## Limits

- This version runs small models on the device, so it is less accurate than the Claude-powered FindIt. It can miss small
  objects, mix up similar ones, and misread curved, glossy, handwritten or very small text.
- Positions and distances are rough estimates from the photo, not measurements.
- Label fields (strength, expiry, directions) are picked out by pattern matching; always check the full text shown below them.
- **Always check medicine names, doses and expiry dates with a pharmacist or someone you trust.**

## Files

```
index.html, app.js          the app
sw.js, manifest.webmanifest offline support and "install as app"
icons/                      app icons
vendor/                     Transformers.js + ONNX Runtime (WebAssembly), Tesseract.js (bundled, offline)
lang/eng.traineddata        English text-recognition model (tessdata_fast)
Start FindIt (...)          double-click launchers for computers
```

## Licences

Transformers.js and ONNX Runtime Web: Apache-2.0. Tesseract.js and tesseract.js-core: Apache-2.0.
Tesseract English model (tessdata_fast): Apache-2.0. OWL-ViT model: Apache-2.0. Licence files are in `vendor/`.
