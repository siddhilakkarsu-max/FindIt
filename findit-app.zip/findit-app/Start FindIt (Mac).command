#!/bin/bash
# Double-click to run FindIt on this Mac. Keep this window open while you use it.
cd "$(dirname "$0")"
PORT=8765
echo "FindIt is running at http://localhost:$PORT  (close this window to stop)"
( sleep 1; open "http://localhost:$PORT" ) &
python3 -m http.server $PORT --bind 127.0.0.1
