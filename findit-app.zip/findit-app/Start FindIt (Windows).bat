@echo off
REM Double-click to run FindIt on this PC. Keep this window open while you use it.
cd /d "%~dp0"
set PORT=8765
echo FindIt is running at http://localhost:%PORT%  (close this window to stop)
start "" "http://localhost:%PORT%"
python -m http.server %PORT% --bind 127.0.0.1 || py -m http.server %PORT% --bind 127.0.0.1
