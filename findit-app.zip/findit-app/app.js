// FindIt — on-device object finding (OWL-ViT via transformers.js) and text reading (Tesseract OCR).
// No server, no account: photos never leave the device. Models are cached by the browser after first use.
import { pipeline, env, RawImage } from "./vendor/transformers.min.js";

// ------------------------------------------------------------------ setup
const MODEL = "Xenova/owlvit-base-patch32";            // open-vocabulary detector: finds any object you name
env.allowLocalModels = false;
env.useBrowserCache = true;                             // keep the model for offline use
env.backends.onnx.wasm.wasmPaths = new URL("./vendor/", location.href).href;
env.backends.onnx.wasm.numThreads = self.crossOriginIsolated ? Math.min(4, navigator.hardwareConcurrency || 2) : 1;

const $ = (id) => document.getElementById(id);
const canvas = $("canvas"), ctx = canvas.getContext("2d");
const ui = {
  status: $("status"), setup: $("setup"), setupText: $("setupText"), bar: $("bar"), download: $("downloadBtn"),
  file: $("file"), takeLabel: $("takeLabel"), tag: $("tag"), photoBox: $("photoBox"), video: $("video"),
  live: $("liveBtn"), shutter: $("shutterBtn"), tabFind: $("tabFind"), tabRead: $("tabRead"),
  findPanel: $("findPanel"), readPanel: $("readPanel"), chips: $("chips"), q: $("q"), mic: $("micBtn"),
  find: $("findBtn"), readChips: $("readChips"), read: $("readBtn"), result: $("result"), verdict: $("verdict"),
  where: $("where"), meta: $("meta"), readout: $("readout"), fields: $("fields"), fullWrap: $("fullWrap"),
  fulltext: $("fulltext"), smaller: $("smaller"), bigger: $("bigger"), readLabel: $("readLabelBtn"),
  speak: $("speakBtn"), stop: $("stopBtn"), announcer: $("announcer"),
};

const state = { photo: null, full: null, mid: null, item: "", readKind: "all", lastBox: null, lastWhat: "", busy: false,
  detector: null, detectorLoading: null, ocr: null, ocrLoading: null, lastSpoken: "" };

const store = {
  get(k) { try { return localStorage.getItem(k); } catch { return null; } },
  set(k, v) { try { localStorage.setItem(k, v); } catch {} },
};

// ------------------------------------------------------------------ vocabulary
const SYNONYMS = {
  keys: ["keys", "a set of keys", "a key ring"], key: ["keys", "a key"],
  phone: ["a mobile phone", "a smartphone", "a cell phone"], wallet: ["a wallet", "a purse"],
  glasses: ["eyeglasses", "glasses", "sunglasses"], remote: ["a remote control", "a tv remote"],
  cup: ["a cup", "a mug"], mug: ["a mug", "a cup"], medicine: ["a medicine bottle", "a pill bottle", "a pill box"],
  bag: ["a bag", "a backpack", "a handbag"], book: ["a book"], bottle: ["a bottle"], laptop: ["a laptop"],
  headphones: ["headphones", "earbuds"], watch: ["a wristwatch"], shoes: ["shoes", "a shoe"], umbrella: ["an umbrella"],
  charger: ["a phone charger", "a charging cable"], milk: ["a milk carton", "a milk bottle"], can: ["a can", "a tin can"],
  box: ["a box", "a cardboard box"], jar: ["a jar"], cane: ["a white cane", "a walking stick"],
};
const LANDMARKS = ["table", "kitchen counter", "sofa", "bed", "shelf", "desk", "chair", "sink", "cabinet", "nightstand", "floor"];
const ON_SURFACES = new Set(["table", "kitchen counter", "bed", "shelf", "desk", "chair", "sofa", "nightstand", "cabinet", "floor", "sink"]);
const STOP = new Set("a an the my our your his her their this that these those is are where what find locate look for please can you help me i to of in on at it its with and or some any".split(" "));

// ------------------------------------------------------------------ small helpers
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function announce(t) { ui.announcer.textContent = ""; setTimeout(() => { ui.announcer.textContent = t; }, 50); }
function setStatus(text, cls = "") { ui.status.textContent = text; ui.status.className = "status " + cls; }
function pill(cls, txt) { const s = document.createElement("span"); s.className = "pill " + cls; s.textContent = txt; return s; }

function setResult(stateName, verdict, where = "", pills = []) {
  ui.result.dataset.state = stateName;
  ui.verdict.textContent = verdict;
  ui.where.textContent = where; ui.where.hidden = !where;
  ui.meta.replaceChildren(...pills.map(([c, t]) => pill(c, t)));
  ui.readout.hidden = true;
}
function busy(on, label) {
  state.busy = on;
  ui.find.disabled = ui.read.disabled = on;
  if (on) { ui.result.dataset.state = "idle"; ui.verdict.textContent = label; ui.where.textContent = "This can take a few seconds on this device."; ui.where.hidden = false; ui.meta.replaceChildren(); ui.readout.hidden = true; ui.readLabel.hidden = true; }
}

// ------------------------------------------------------------------ speech output
const tts = "speechSynthesis" in window ? window.speechSynthesis : null;
let ttsUnlocked = false;
if (!tts) ui.speak.hidden = true;
function unlockSpeech() { if (tts && !ttsUnlocked) { try { tts.speak(new SpeechSynthesisUtterance(" ")); ttsUnlocked = true; } catch {} } }
function speak(text) {
  if (!tts || !text) return;
  try { tts.cancel(); const u = new SpeechSynthesisUtterance(text); u.rate = 0.95;
    u.onend = u.onerror = () => { ui.stop.hidden = true; }; ui.stop.hidden = false; tts.speak(u); } catch {}
}
function say(text) { state.lastSpoken = text; speak(text); announce(text); }
ui.speak.onclick = () => speak(state.lastSpoken || `${ui.verdict.textContent} ${ui.where.textContent}`);
ui.stop.onclick = () => { try { tts.cancel(); } catch {} ui.stop.hidden = true; };

// ------------------------------------------------------------------ speech input (where the browser supports it)
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
if (SR) {
  ui.mic.hidden = false;
  ui.mic.onclick = () => {
    const rec = new SR(); rec.lang = navigator.language || "en-US"; rec.interimResults = false; rec.maxAlternatives = 1;
    ui.mic.textContent = "…"; announce("Listening");
    rec.onresult = (e) => { ui.q.value = e.results[0][0].transcript; clearChips(); state.item = ""; find(); };
    rec.onend = () => { ui.mic.textContent = "🎤"; };
    rec.onerror = () => { ui.mic.textContent = "🎤"; say("I didn't catch that. Try again or type it."); };
    try { rec.start(); } catch {}
  };
}

// ------------------------------------------------------------------ images
async function loadImage(src) {
  const img = new Image(); img.src = src; await img.decode(); return img;
}
function scaledCanvas(img, maxSide) {
  const s = Math.min(1, maxSide / Math.max(img.naturalWidth || img.width, img.naturalHeight || img.height));
  const c = document.createElement("canvas");
  c.width = Math.round((img.naturalWidth || img.width) * s); c.height = Math.round((img.naturalHeight || img.height) * s);
  c.getContext("2d").drawImage(img, 0, 0, c.width, c.height);
  return c;
}
const toBlob = (c, q = 0.9) => new Promise((r) => c.toBlob(r, "image/jpeg", q));

async function usePhoto(src) {
  const img = await loadImage(src);
  state.full = scaledCanvas(img, 4096);                  // full-resolution copy: zoomed crops come from here
  state.mid = scaledCanvas(img, 2400);                   // whole-photo text reading
  state.photo = scaledCanvas(img, 1280);                 // display + object finding
  state.lastBox = null; ui.readLabel.hidden = true;
  drawPhoto();
  ui.tag.hidden = true; ui.photoBox.classList.add("has-photo"); canvas.setAttribute("aria-label", "Your photo");
  ui.takeLabel.textContent = "Retake photo";
  setResult("idle", "Photo ready.", ui.tabRead.getAttribute("aria-selected") === "true" ? "Tap “Read it”." : "Choose what to find.");
  announce("Photo ready.");
}
function drawPhoto() {
  if (!state.photo) return;
  canvas.width = state.photo.width; canvas.height = state.photo.height; ctx.drawImage(state.photo, 0, 0);
}
function drawBox(b, label) {
  const W = canvas.width, H = canvas.height, lw = Math.max(4, Math.round(Math.min(W, H) / 120));
  const x = b[0] * W - lw * 2, y = b[1] * H - lw * 2, w = (b[2] - b[0]) * W + lw * 4, h = (b[3] - b[1]) * H + lw * 4;
  ctx.save();
  ctx.lineWidth = lw * 2.2; ctx.strokeStyle = "#111114"; ctx.strokeRect(x, y, w, h);
  ctx.lineWidth = lw; ctx.strokeStyle = "#FFC21A"; ctx.strokeRect(x, y, w, h);
  if (label) {
    const fs = Math.max(18, Math.round(Math.min(W, H) / 22)); ctx.font = `700 ${fs}px Verdana, sans-serif`;
    const tw = ctx.measureText(label).width + fs * 0.8, th = fs * 1.5, ty = y - th - lw > 0 ? y - th - lw : y + h + lw;
    ctx.fillStyle = "#FFC21A"; ctx.fillRect(x, ty, tw, th); ctx.fillStyle = "#111114"; ctx.textBaseline = "middle"; ctx.fillText(label, x + fs * 0.4, ty + th / 2);
  }
  ctx.restore();
}

ui.file.onchange = async () => {
  const f = ui.file.files && ui.file.files[0]; if (!f) return;
  const url = URL.createObjectURL(f);
  try { await usePhoto(url); } catch { setResult("error", "That photo couldn't be opened.", "Try again with a JPEG or PNG."); }
  URL.revokeObjectURL(url); ui.file.value = "";
};

// live camera (works on https:// or localhost)
let stream = null;
ui.live.onclick = async () => {
  if (stream) { stopCamera(); return; }
  try {
    stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: "environment", width: { ideal: 1920 } }, audio: false });
    ui.video.srcObject = stream; await ui.video.play();
    ui.video.hidden = false; canvas.hidden = true; ui.tag.hidden = true; ui.shutter.hidden = false; ui.live.textContent = "Close camera";
    announce("Camera on. Tap Capture.");
  } catch { setResult("error", "The camera couldn't be opened.", "Allow camera access, or use “Take a photo” instead."); }
};
function stopCamera() {
  stream?.getTracks().forEach((t) => t.stop()); stream = null;
  ui.video.hidden = true; canvas.hidden = false; ui.shutter.hidden = true; ui.live.textContent = "Use live camera";
}
ui.shutter.onclick = async () => {
  const c = document.createElement("canvas"); c.width = ui.video.videoWidth; c.height = ui.video.videoHeight;
  c.getContext("2d").drawImage(ui.video, 0, 0); stopCamera();
  await usePhoto(c.toDataURL("image/jpeg", 0.92));
};

// ------------------------------------------------------------------ models
async function getDetector(showProgress = true) {
  if (state.detector) return state.detector;
  if (state.detectorLoading) return state.detectorLoading;
  const files = {};
  const progress_callback = (p) => {
    if (p.status === "progress" && p.total) {
      files[p.file] = [p.loaded, p.total];
      const [l, t] = Object.values(files).reduce((a, [x, y]) => [a[0] + x, a[1] + y], [0, 0]);
      const pct = Math.round((l / t) * 100);
      ui.bar.style.width = pct + "%";
      if (showProgress) setStatus(`Downloading ${pct}%`, "busy");
    }
  };
  state.detectorLoading = (async () => {
    const tries = navigator.gpu ? [{ device: "webgpu", dtype: "fp32" }, { device: "wasm", dtype: "q8" }] : [{ device: "wasm", dtype: "q8" }];
    let lastErr;
    for (const opt of tries) {
      try {
        const d = await pipeline("zero-shot-object-detection", MODEL, { ...opt, progress_callback });
        state.detector = d; store.set("findit-model", "1"); ui.setup.hidden = true; updateStatus();
        return d;
      } catch (e) { lastErr = e; console.warn("detector load failed", opt, e); }
    }
    state.detectorLoading = null;
    throw lastErr;
  })();
  return state.detectorLoading;
}

async function getOCR() {
  if (state.ocr) return state.ocr;
  if (state.ocrLoading) return state.ocrLoading;
  state.ocrLoading = (async () => {
    const base = new URL("./", location.href).href;
    const w = await window.Tesseract.createWorker("eng", 1, {
      workerPath: base + "vendor/worker.min.js", corePath: base + "vendor/tesseract-core", langPath: base + "lang", gzip: false,
    });
    state.ocr = w; return w;
  })();
  return state.ocrLoading;
}

function updateStatus() {
  if (state.detector) setStatus("Ready · offline", "ready");
  else if (store.get("findit-model")) setStatus("Loading…", "busy");
  else setStatus("Text reader ready", "");
}

ui.download.onclick = async () => {
  ui.download.disabled = true; ui.setupText.textContent = "Downloading… keep this page open.";
  try { await getDetector(); ui.setupText.textContent = "Done. FindIt now works offline."; say("Download finished. FindIt is ready."); }
  catch { ui.download.disabled = false; ui.setupText.textContent = "The download didn't finish. Check your internet connection and try again."; setStatus("Download failed", "busy"); }
};

// ------------------------------------------------------------------ OCR with rotation (book spines read sideways)
function rotatedCanvas(src, deg) {
  if (!deg) return src;
  const c = document.createElement("canvas");
  c.width = src.height; c.height = src.width;
  const x = c.getContext("2d"); x.translate(c.width / 2, c.height / 2); x.rotate((deg * Math.PI) / 180);
  x.drawImage(src, -src.width / 2, -src.height / 2);
  return c;
}
// map a point (px,py) in the rotated image back to normalized coords of the original
function unrotate(px, py, deg, W, H) {           // W,H = original size
  if (deg === 90) return [py / W, 1 - px / H];   // rotated canvas is H wide, W tall
  if (deg === 270) return [1 - py / W, px / H];
  return [px / W, py / H];
}
async function ocrLines(src, deg = 0, region = null, sparse = false, bw = false) {
  const w = await getOCR();
  // bw: local black-and-white first, which rescues tiny print on busy backgrounds (thin spines on a shelf)
  const c = rotatedCanvas(bw ? binarize(src, (Math.round(9 * src.width / Math.max(1, (region ? region[2] - region[0] : 1) * state.full.width)) | 1), false, 0) : src, deg);
  // sparse mode looks for scattered bits of text (e.g. many thin spines side by side) instead of one block
  if (sparse) await w.setParameters({ tessedit_pageseg_mode: "11" });
  let data;
  try { ({ data } = await w.recognize(c, {}, { text: true, blocks: true })); }
  finally { if (sparse) await w.setParameters({ tessedit_pageseg_mode: "6" }); }
  const W = src.width, H = src.height, lines = [];
  // how much this canvas is enlarged relative to the full photo, so letter sizes are comparable across zoom levels
  const scale = region ? W / Math.max(1, (region[2] - region[0]) * state.full.width) : W / state.full.width;
  // keep every word, even garbled low-confidence ones, as places worth a closer second look
  if (state.raw) for (const b of data.blocks || []) for (const p of b.paragraphs || []) for (const l of p.lines || []) for (const wd of l.words || []) {
    if (!/[A-Za-z]/.test(wd.text)) continue;
    const [ax, ay] = unrotate(wd.bbox.x0, wd.bbox.y0, deg, W, H), [bx, by] = unrotate(wd.bbox.x1, wd.bbox.y1, deg, W, H);
    let box = [Math.min(ax, bx), Math.min(ay, by), Math.max(ax, bx), Math.max(ay, by)];
    if (region) box = mapToRegion(box, region);
    state.raw.push({ text: wd.text, conf: wd.confidence, box, deg, size: (wd.bbox.y1 - wd.bbox.y0) / scale });
  }
  for (const b of data.blocks || []) for (const p of b.paragraphs || []) for (const l of p.lines || []) {
    const words = (l.words || []).filter((wd) => wd.confidence >= 45 && /[A-Za-z0-9]/.test(wd.text) && !(/^[A-Za-z]{1,2}$/.test(wd.text) && wd.confidence < 85)).map((wd) => {
      const [ax, ay] = unrotate(wd.bbox.x0, wd.bbox.y0, deg, W, H), [bx, by] = unrotate(wd.bbox.x1, wd.bbox.y1, deg, W, H);
      return { text: wd.text, conf: wd.confidence, h: wd.bbox.y1 - wd.bbox.y0, box: [Math.min(ax, bx), Math.min(ay, by), Math.max(ax, bx), Math.max(ay, by)] };
    });
    if (!words.length) continue;
    const text = words.map((x) => x.text).join(" ");
    if (text.replace(/[^A-Za-z0-9]/g, "").length < 2) continue;
    const box = [Math.min(...words.map((x) => x.box[0])), Math.min(...words.map((x) => x.box[1])), Math.max(...words.map((x) => x.box[2])), Math.max(...words.map((x) => x.box[3]))];
    const hs = words.map((x) => x.h).sort((p, q) => p - q), size = hs[Math.floor(hs.length / 2)] / scale;   // median letter height, in full-photo pixels
    lines.push({ text, words, box, conf: words.reduce((a, x) => a + x.conf, 0) / words.length, size, deg });
  }
  if (region) for (const l of lines) { l.box = mapToRegion(l.box, region); for (const wd of l.words) wd.box = mapToRegion(wd.box, region); }
  return lines;
}
function mapToRegion(b, r) { return [r[0] + b[0] * (r[2] - r[0]), r[1] + b[1] * (r[3] - r[1]), r[0] + b[2] * (r[2] - r[0]), r[1] + b[3] * (r[3] - r[1])]; }

// fuzzy text matching
const norm = (s) => s.toLowerCase().normalize("NFKD").replace(/[^a-z0-9]/g, "");
function lev(a, b) {
  const m = a.length, n = b.length; if (!m || !n) return Math.max(m, n);
  let prev = Array.from({ length: n + 1 }, (_, j) => j);
  for (let i = 1; i <= m; i++) { const cur = [i]; for (let j = 1; j <= n; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; }
  return prev[n];
}
const sim = (a, b) => 1 - lev(a, b) / Math.max(a.length, b.length, 1);
function bestTextMatch(lines, target) {
  const t = norm(target); if (t.length < 2) return null;
  let best = null;
  for (const l of lines) {
    const ws = l.words;
    for (let i = 0; i < ws.length; i++) for (let j = i; j < Math.min(ws.length, i + 8); j++) {
      const span = ws.slice(i, j + 1), s = norm(span.map((x) => x.text).join(""));
      if (!s) continue;
      const score = s.includes(t) && t.length >= 4 ? 0.97 : sim(s, t);
      if (!best || score > best.score) best = { score, text: span.map((x) => x.text).join(" "),
        box: [Math.min(...span.map((x) => x.box[0])), Math.min(...span.map((x) => x.box[1])), Math.max(...span.map((x) => x.box[2])), Math.max(...span.map((x) => x.box[3]))] };
    }
  }
  return best;
}

// ------------------------------------------------------------------ understanding the question
function parseQuery(raw) {
  let s = raw.trim().replace(/[?.!]+$/, "");
  s = s.replace(/^(hey,?\s*)?(please\s*)?(can you\s*)?(help me\s*)?(find|where('?s| is| are)|look for|locate|show me)\s+/i, "");
  s = s.replace(/^(my|the|a|an|our|your)\s+/i, "");
  let text = null, object = s;
  const quoted = s.match(/["“'‘](.+?)["”'’]/);
  const named = s.match(/^(.*?)\s*(?:titled|called|named|labell?ed|that says|which says|says|brand)\s+(.+)$/i);
  if (quoted) { text = quoted[1]; object = s.replace(quoted[0], "").replace(/\s*(titled|called|named)\s*$/i, "").trim(); }
  else if (named) { object = named[1].trim(); text = named[2].trim(); }
  object = object.replace(/^(my|the|a|an)\s+/i, "").trim();
  const head = object.split(/\s+/).pop()?.toLowerCase() || "";
  const known = SYNONYMS[object.toLowerCase()] || SYNONYMS[head] || SYNONYMS[head.replace(/s$/, "")];
  if (!text && !known) {
    // e.g. "tylenol", "oat milk": words that aren't common objects may be printed on the item
    const words = object.split(/\s+/).filter((w) => !STOP.has(w.toLowerCase()) && !SYNONYMS[w.toLowerCase()]);
    if (words.length && words.join("").length >= 4) text = words.join(" ");
  }
  const labels = known ? known : object ? [object] : [];
  const display = text && object && norm(object) !== norm(text) ? `${object} “${text}”` : (object || text || raw);
  return { raw, object: object || text || raw, text, labels, display };
}

// ------------------------------------------------------------------ describing where something is
function describe(box, landmarks) {
  const cx = (box[0] + box[2]) / 2, cy = (box[1] + box[3]) / 2, area = (box[2] - box[0]) * (box[3] - box[1]);
  const side = cx < 0.34 ? "on the left side" : cx > 0.66 ? "on the right side" : "near the middle";
  const height = cy < 0.3 ? ", high up" : cy > 0.72 ? ", low down" : "";
  let hour = Math.round(12 + (cx - 0.5) * 4); if (hour > 12) hour -= 12;
  const dist = area > 0.2 ? "within reach" : area > 0.05 ? "an arm's length away" : area > 0.012 ? "a few steps away" : "across the room";
  let rel = "";
  let bestScore = 0;
  for (const l of landmarks) {
    const b = l.box, ox = Math.max(0, Math.min(box[2], b[2]) - Math.max(box[0], b[0])) / Math.max(1e-6, box[2] - box[0]);
    const bottom = box[3];
    const onIt = ox > 0.5 && bottom >= b[1] - 0.03 && bottom <= b[1] + (b[3] - b[1]) * 0.6;
    const near = ox > 0 || Math.abs((b[0] + b[2]) / 2 - cx) < 0.25;
    const score = (onIt ? 2 : near ? 1 : 0) * l.score;
    if (score > bestScore) { bestScore = score; rel = onIt && ON_SURFACES.has(l.label) ? `on the ${l.label}` : `next to the ${l.label}`; }
  }
  const relPart = rel && bestScore > 0.15 ? `${rel}, ` : "";
  return `It's ${relPart}${side} of the photo${height}, at about ${hour} o'clock, roughly ${dist}.`;
}


// ------------------------------------------------------------------ ZOOM: look again at parts of the sharp photo
// Small objects and small print shrink to a few pixels in a whole-photo view, so we also look at overlapping
// zoomed-in crops of the full-resolution copy and map what we find back onto the photo.
function cropCanvas(r, maxSide = 1600, maxUp = 3) {
  const src = state.full, W = src.width, H = src.height;
  const sw = Math.max(1, (r[2] - r[0]) * W), sh = Math.max(1, (r[3] - r[1]) * H), sc = Math.min(maxUp, maxSide / Math.max(sw, sh));
  const c = document.createElement("canvas"); c.width = Math.round(sw * sc); c.height = Math.round(sh * sc);
  const x = c.getContext("2d"); x.imageSmoothingQuality = "high"; x.drawImage(src, r[0] * W, r[1] * H, sw, sh, 0, 0, c.width, c.height);
  return c;
}
function gridRegions(cols, rows, ov = 0.15) {
  const out = [];
  for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++)
    out.push([Math.max(0, (c - ov) / cols), Math.max(0, (r - ov) / rows), Math.min(1, (c + 1 + ov) / cols), Math.min(1, (r + 1 + ov) / rows)]);
  return out;
}
function zoomGrid(fine = true) {
  const land = state.full.width >= state.full.height;
  return fine ? (land ? gridRegions(4, 3) : gridRegions(3, 4)) : (land ? gridRegions(3, 2) : gridRegions(2, 3));
}
function iou(a, b) {
  const ix = Math.max(0, Math.min(a[2], b[2]) - Math.max(a[0], b[0])), iy = Math.max(0, Math.min(a[3], b[3]) - Math.max(a[1], b[1]));
  const inter = ix * iy, u = (a[2] - a[0]) * (a[3] - a[1]) + (b[2] - b[0]) * (b[3] - b[1]) - inter;
  return u > 0 ? inter / u : 0;
}
function nms(dets, thr = 0.45) {
  const keep = [];
  for (const d of [...dets].sort((a, b) => b.score - a.score))
    if (!keep.some((k) => k.label === d.label && iou(k.box, d.box) > thr)) keep.push(d);
  return keep;
}
async function detectIn(r, labels) {
  const det = await getDetector();
  const img = await RawImage.fromBlob(await toBlob(cropCanvas(r, 1024, 2)));
  const out = await det(img, labels, { threshold: 0.08, percentage: true });
  return out.map((o) => {
    let { xmin, ymin, xmax, ymax } = o.box;
    if (Math.max(xmax, ymax) > 1.5) { xmin /= img.width; xmax /= img.width; ymin /= img.height; ymax /= img.height; }
    return { label: o.label, score: o.score, box: mapToRegion([xmin, ymin, xmax, ymax], r), zoomed: true };
  });
}
function mergeLines(base, extra) {
  for (const l of extra) {
    const t = norm(l.text);
    const dup = base.findIndex((b) => iou(b.box, l.box) > 0.1 && sim(norm(b.text), t) > 0.6 || (t.length > 5 && norm(b.text).includes(t)));
    if (dup < 0) base.push(l);
    else if (l.conf > base[dup].conf + 5 && norm(l.text).length >= norm(base[dup].text).length * 0.8) base[dup] = l;
  }
  return base;
}

// ------------------------------------------------------------------ CLOSE CHECK: re-read promising spots up close
// Tiny print (a thin book spine, a far-away label) usually comes out garbled the first time ("aL_anr" for BLANK),
// but it shows *where* text is. We re-read the spots that look most like the name, cropped tightly, enlarged
// until letters are big, turned black-and-white with a local threshold, and read as a single line.
function binarize(src, win, light, P = 16) {
  const W = src.width, H = src.height, d = src.getContext("2d").getImageData(0, 0, W, H).data;
  const g = new Float32Array(W * H), I = new Float64Array((W + 1) * (H + 1));
  for (let i = 0; i < W * H; i++) g[i] = 0.299 * d[i * 4] + 0.587 * d[i * 4 + 1] + 0.114 * d[i * 4 + 2];
  for (let y = 0; y < H; y++) { let row = 0; for (let x = 0; x < W; x++) { row += g[y * W + x]; I[(y + 1) * (W + 1) + x + 1] = I[y * (W + 1) + x + 1] + row; } }
  const c = document.createElement("canvas"); c.width = W + 2 * P; c.height = H + 2 * P;
  const cx = c.getContext("2d"); cx.fillStyle = "#fff"; cx.fillRect(0, 0, c.width, c.height);
  const out = cx.createImageData(W, H), o = out.data, r = win >> 1;
  for (let y = 0; y < H; y++) {
    const y0 = Math.max(0, y - r), y1 = Math.min(H, y + r + 1);
    for (let x = 0; x < W; x++) {
      const x0 = Math.max(0, x - r), x1 = Math.min(W, x + r + 1);
      const m = (I[y1 * (W + 1) + x1] - I[y0 * (W + 1) + x1] - I[y1 * (W + 1) + x0] + I[y0 * (W + 1) + x0]) / ((x1 - x0) * (y1 - y0));
      const v = g[y * W + x], ink = light ? v > m + 8 : v < m - 8, k = (y * W + x) * 4;
      o[k] = o[k + 1] = o[k + 2] = ink ? 0 : 255; o[k + 3] = 255;
    }
  }
  cx.putImageData(out, P, P);
  return c;
}
// letters OCR often mixes up, folded together before comparing
const fold = (s) => s.replace(/rn/g, "m").replace(/m/g, "n").replace(/[1il|]/g, "l").replace(/0/g, "o").replace(/5/g, "s").replace(/8/g, "b").replace(/vv/g, "w").replace(/cl/g, "d");
function closeCandidates(target, raws, checked) {
  const t = fold(norm(target)), tw = target.split(/\s+/).filter((x) => !STOP.has(x.toLowerCase()) && !/^(in|of|on|at|to|and|or|for|with|by)$/i.test(x)).map((x) => fold(norm(x))).filter((w) => w.length >= 4);
  const scored = [];
  for (const r of raws) {
    const w = fold(norm(r.text)); if (w.length < 2 || r.size < 2) continue;
    let s = sim(w, t);
    if (w.length > t.length) for (let i = 0; i + t.length <= w.length; i++) s = Math.max(s, sim(w.substr(i, t.length), t) * 0.85);
    for (const x of tw) s = Math.max(s, sim(w, x) * (tw.length > 1 ? 0.9 : 1));
    if (w.length >= 3 && w.length < t.length) for (let i = 0; i + w.length <= t.length; i++) s = Math.max(s, sim(w, t.substr(i, w.length)) * 0.8);
    if (s >= 0.34) scored.push({ ...r, s });
  }
  scored.sort((a, b) => b.s - a.s);
  const keep = [];
  for (const c of scored) {
    if (keep.length >= 10) break;
    if (keep.some((k) => iou(k.box, c.box) > 0.3) || checked.some((k) => iou(k, c.box) > 0.5)) continue;
    keep.push(c);
  }
  return keep;
}
async function reRead(cand, target) {
  const F = state.full, W = F.width, H = F.height;
  const vertical = cand.deg === 90 || cand.deg === 270;
  const [x0, y0, x1, y1] = [cand.box[0] * W, cand.box[1] * H, cand.box[2] * W, cand.box[3] * H];
  const along = vertical ? y1 - y0 : x1 - x0, cross = vertical ? x1 - x0 : y1 - y0, ca = vertical ? (x0 + x1) / 2 : (y0 + y1) / 2;
  // The first read's box and letter size are rough, and tiny print only reads when the enlargement and framing are
  // about right, so try several guesses (most likely first) and stop at the first clear reading.
  // [letter-size factor, nudge across the line, framing width, letter height to enlarge to]
  const guesses = [[1.4, 0, 1, 27], [1.4, 0, 1, 33], [1, 0, 1, 27], [1.8, 0, 1, 27], [1.4, 0, 1.4, 27], [1.4, -0.3, 1, 27],
    [1.4, 0.3, 1, 27], [1, 0, 1, 33], [1.8, 0, 1, 33], [1.4, 0, 1, 22]];
  const w = await getOCR();
  let best = null, support = 0;
  await w.setParameters({ tessedit_pageseg_mode: "7" });           // one line of text
  try {
    for (let gi = 0; gi < guesses.length; gi++) {
      const [sm, shift, m, L] = guesses[gi];
      if (gi === 3 && (!best || best.score < 0.5)) break;  // nothing like the name after a few tries: move on
      const size = Math.max(3, cand.size * sm);
      // along the text: stretch to fit the whole name (the garbled word may be only part of it); across: a little margin
      const want = Math.max(along, size * 0.65 * norm(target).length) * 1.25, ea = Math.max(size * 0.5, (want - along) / 2);
      const c0 = ca + shift * size, hh = (cross / 2 + size * 0.6) * m;
      const b = vertical ? [c0 - hh, y0 - ea, c0 + hh, y1 + ea] : [x0 - ea, c0 - hh, x1 + ea, c0 + hh];
      const r = [Math.max(0, b[0] / W), Math.max(0, b[1] / H), Math.min(1, b[2] / W), Math.min(1, b[3] / H)];
      const crop = rotatedCanvas(cropCanvas(r, 2400, Math.max(1, Math.min(8, L / size))), cand.deg), win = Math.round(L * 1.6) | 1;
      for (const img of [binarize(crop, win, false), binarize(crop, win, true), crop]) {
        const words = ((await w.recognize(img)).data.text || "").split(/\s+/).filter(Boolean).map((x) => ({ text: x, box: r }));
        const mt = bestTextMatch([{ words }], target);
        if (mt && mt.score >= 0.6) support++;            // part of the name read again here
        if (mt && (!best || mt.score > best.score)) best = { ...mt, box: cand.box, region: r };
        if (best && best.score >= 0.9) return { ...best, support };
      }
    }
  } finally { await w.setParameters({ tessedit_pageseg_mode: "6" }); }
  return best && { ...best, support };
}

// ------------------------------------------------------------------ FIND
async function detect(labels) {
  const det = await getDetector();
  const img = await RawImage.fromBlob(await toBlob(state.photo));
  const out = await det(img, labels, { threshold: 0.05, percentage: true });
  return out.map((o) => {
    let { xmin, ymin, xmax, ymax } = o.box;
    if (Math.max(xmax, ymax) > 1.5) { xmin /= state.photo.width; xmax /= state.photo.width; ymin /= state.photo.height; ymax /= state.photo.height; }
    return { label: o.label, score: o.score, box: [xmin, ymin, xmax, ymax] };
  });
}

async function find() {
  unlockSpeech();
  if (state.busy) return;
  const raw = state.item || ui.q.value;
  if (!state.photo) { setResult("notfound", "Take a photo first."); say("Take a photo first."); return; }
  if (!raw.trim()) { setResult("notfound", "Choose what to find.", "Tap an item, or say or type what you're looking for."); say("Choose what to find."); return; }
  const Q = parseQuery(raw);
  drawPhoto(); state.lastBox = null; ui.readLabel.hidden = true; busy(true, `Looking for ${Q.display}…`); announce("Looking for " + Q.display);
  try {
    let dets = [], detectorOk = true;
    if (Q.labels.length) {
      try {
        if (!state.detector) { ui.where.textContent = store.get("findit-model") ? "Loading the object finder…" : "Downloading the object finder (one time, about 150 MB)…"; }
        dets = await detect([...new Set([...Q.labels, ...LANDMARKS])]);
      } catch (e) { console.warn(e); detectorOk = false; }
    }
    let targets = dets.filter((d) => Q.labels.includes(d.label)).sort((a, b) => b.score - a.score);
    const landmarks = dets.filter((d) => LANDMARKS.includes(d.label) && d.score > 0.1);

    // Zoom pass for objects: small things (keys, glasses, a pill box) are easier to spot in close-up parts.
    if (detectorOk && Q.labels.length && (!targets.length || targets[0].score < 0.2)) {
      const regions = zoomGrid(false);
      for (let i = 0; i < regions.length; i++) {
        ui.verdict.textContent = `Looking closer… (part ${i + 1} of ${regions.length})`;
        ui.where.textContent = "Zooming in on each part of the photo to spot small things.";
        try { targets.push(...(await detectIn(regions[i], Q.labels)).filter((d) => d.score >= 0.12)); } catch (e) { console.warn(e); break; }
        const best = targets.reduce((m, d) => Math.max(m, d.score), 0);
        if (best >= 0.35) break;                               // clear hit: stop early
      }
      targets = nms(targets).sort((a, b) => b.score - a.score);
    }

    let match = null;
    if (Q.text) {
      const take = (lines) => { const m = bestTextMatch(lines, Q.text); if (m && (!match || m.score > match.score)) match = m; return match && match.score >= 0.9; };
      const step = (v, w) => { if (window.__dbg) console.log('dbg t', (performance.now() / 1000).toFixed(1), v); ui.verdict.textContent = v; ui.where.textContent = w; };
      const checked = []; let weak = null;
      const closeCheck = async (where = "") => {                    // re-read the most promising garbled spots up close
        if (checked.length >= 40) return false;          // enough close looks for one search
        const cs = closeCandidates(Q.text, state.raw, checked).slice(0, 40 - checked.length);
        for (let i = 0; i < cs.length; i++) {
          step(where ? `Zooming in… (${where}, checking up close)` : `Checking up close… (${i + 1} of ${cs.length})`, "Re-reading spots that might be the name, enlarged.");
          checked.push(cs[i].box);
          const m = await reRead(cs[i], Q.text);
          if (window.__dbg) console.log('dbg', cs[i].text, cs[i].deg, cs[i].size.toFixed(1), cs[i].s.toFixed(2), cs[i].box.map((v) => v.toFixed(3)).join(','), '->', m && m.text, m && m.score.toFixed(2));
          if (m && (!match || m.score > match.score)) match = m;
          // several partial readings of the same spot (e.g. "ALAN", "BLA", "nLANK" for BLANK) = a possible match
          if (m && m.score >= 0.6 && m.support >= 3 && norm(Q.text).length >= 4 && (!weak || m.support > weak.support)) weak = m;
          if (match && match.score >= 0.9) return true;
        }
        return false;
      };
      state.raw = [];
      step(`Looking for “${Q.text}”…`, "Reading labels in the whole photo.");
      let done = take(await ocrLines(state.mid, 0));
      // 1) zoom into each candidate object the finder saw (e.g. every book), reading upright and sideways
      const cands = targets.filter((t) => t.score > 0.05).slice(0, 6);
      for (let i = 0; !done && i < cands.length; i++) {
        step(`Reading item ${i + 1} of ${cands.length}…`, "Zooming in on each possible match to read its label.");
        const b = padBox(cands[i].box, 0.02), c = cropCanvas(b, 1600, 3);
        for (const deg of [0, 90, 270]) { if (take(await ocrLines(c, deg, b))) { done = true; break; } }
      }
      // 2) whole photo turned sideways (book spines are printed vertically)
      for (const deg of [270, 90]) { if (done) break; step("Reading sideways text…", "Book spines and some labels are printed sideways."); done = take(await ocrLines(state.mid, deg)); }
      if (!done) done = await closeCheck();
      // 3) zoom into each part for small print: upright text in tiles, sideways text in tall strips (keeps spines whole)
      const land = state.full.width >= state.full.height;
      const side = land ? gridRegions(5, 2, 0.3) : gridRegions(3, 3, 0.3);   // overlapping tall tiles keep spines readable
      // book titles are usually on spines, printed top-to-bottom (270) on English books, bottom-to-top (90) on many others
      const bookish = /book|novel|spine|notebook|journal|magazine|dvd|cd|game/i.test(Q.object || "");
      const plan = bookish ? [[270, side], [90, side], [0, zoomGrid(true)]] : [[0, zoomGrid(true)], [270, side], [90, side]];
      for (const [deg, regions] of plan) {
        for (let i = 0; !done && i < regions.length; i++) {
          step(`Zooming in… (part ${i + 1} of ${regions.length}${deg ? ", sideways text" : ""})`, "Reading small print in each part of the photo.");
          const tile = cropCanvas(regions[i], 2200, 3);
          done = take(await ocrLines(tile, deg, regions[i]));
          // sideways: also a black-and-white sparse read, which finds tiny spines on busy shelves
          if (!done && deg) done = take(await ocrLines(tile, deg, regions[i], true, true));
          if (!done) done = await closeCheck(`part ${i + 1} of ${regions.length}`);   // re-read garbled spots in this part right away
        }
        if (done) break;
      }
      if (!done) done = await closeCheck();
      state.raw = null;
      if (match && match.score < 0.72) match = null;
      if (!match && weak) match = { ...weak, weak: true };
    }

    let box = null, conf = "low", heard = "";
    if (match) {
      const cx = (match.box[0] + match.box[2]) / 2, cy = (match.box[1] + match.box[3]) / 2;
      const holder = targets.find((t) => cx >= t.box[0] && cx <= t.box[2] && cy >= t.box[1] && cy <= t.box[3] && t.score > 0.06);
      box = holder ? holder.box : padBox(match.box, 0.04);
      conf = match.weak ? "low" : match.score >= 0.9 ? "high" : "medium";
      heard = match.weak ? "" : match.text;
    } else if (targets.length && targets[0].score >= 0.1) {
      box = targets[0].box;
      conf = targets[0].score >= 0.3 ? "high" : targets[0].score >= 0.16 ? "medium" : "low";
      if (Q.text) conf = "low";                          // saw the kind of object but couldn't read the name
    }

    if (box) {
      const name = Q.display.charAt(0).toUpperCase() + Q.display.slice(1);
      let verdict = conf === "low" ? `Possibly found: ${Q.display}.` : `${name} found.`;
      let where = describe(box, landmarks);
      if (heard) where += ` The label reads “${heard}”.`;
      if (match && match.weak) where += ` The letters are very small, so I'm not sure. Move closer and try again to check.`;
      if (Q.text && !match) where += ` I can see a ${Q.object || "match"}, but I couldn't read “${Q.text}” on it. Try “Read its label”.`;
      setResult("found", verdict, where, [[conf, "Confidence: " + conf], ["plain", "Position is approximate"]]);
      drawBox(box, Q.display.length > 18 ? "here" : Q.display);
      state.lastBox = box; state.lastWhat = Q.display; ui.readLabel.hidden = false;
      say(`${verdict} ${where}`);
    } else {
      const seen = [...new Set(landmarks.map((l) => l.label))].slice(0, 3);
      let where = "Try again from another angle, closer, or with more light.";
      if (seen.length) where = `I can see ${listify(seen.map((s) => "a " + s))}. ` + where;
      if (!detectorOk && !Q.text) where = "The object finder isn't downloaded yet. Connect to the internet and tap “Download the object finder”, then try again.";
      setResult("notfound", `I can't see ${Q.display} in this photo.`, where);
      say(`I can't see ${Q.display}. ${where}`);
      if (!detectorOk) ui.setup.hidden = false;
    }
  } catch (e) {
    console.error(e);
    setResult("error", "Something went wrong.", "Try again. If it keeps happening, reload the app.");
    say("Something went wrong. Try again.");
  } finally { busy(false); }
}
function padBox(b, p) { return [Math.max(0, b[0] - p), Math.max(0, b[1] - p), Math.min(1, b[2] + p), Math.min(1, b[3] + p)]; }
function listify(a) { return a.length < 2 ? a.join("") : a.slice(0, -1).join(", ") + " and " + a[a.length - 1]; }

// ------------------------------------------------------------------ READ
function regionCanvas(box) {
  const src = state.full, W = src.width, H = src.height, b = padBox(box, 0.03);
  const px = (b[2] - b[0]) * 0.2, py = (b[3] - b[1]) * 0.2;
  const r = [Math.max(0, b[0] - px), Math.max(0, b[1] - py), Math.min(1, b[2] + px), Math.min(1, b[3] + py)];
  const sw = (r[2] - r[0]) * W, sh = (r[3] - r[1]) * H, sc = Math.min(3, 2000 / Math.max(sw, sh));
  const c = document.createElement("canvas"); c.width = Math.round(sw * sc); c.height = Math.round(sh * sc);
  const x = c.getContext("2d"); x.imageSmoothingQuality = "high"; x.drawImage(src, r[0] * W, r[1] * H, sw, sh, 0, 0, c.width, c.height);
  return { c, r };
}

const RX = {
  strength: /\b\d+(?:[.,]\d+)?\s?(?:mg|mcg|µg|g|ml|mL|iu|IU|%)\b(?:\s*\/\s*\d+(?:[.,]\d+)?\s?(?:ml|mL))?/,
  expiry: /\b(?:exp(?:iry|ires|\.)?|use by|best before|best by|bb)\b[\s:.]*([0-3]?\d[\/\-.][01]?\d[\/\-.]\d{2,4}|[01]?\d[\/\-.]\d{2,4}|[A-Za-z]{3,9}\.?\s?\d{2,4}|\d{1,2}\s?[A-Za-z]{3,9}\s?\d{2,4})/i,
  directions: /\b(take|use|apply|adults?|children|dose|dosage|every \d+ ?(?:hours|hrs))\b/i,
  warning: /\b(warning|caution|do not|keep out of reach|ask a doctor)\b/i,
  allergens: /\b(contains|allergens?|may contain)\b[:\s]*(.+)/i,
  size: /\b\d+(?:[.,]\d+)?\s?(?:oz|fl\.?\s?oz|g|kg|ml|mL|l|L|lb|lbs|ct|count|tablets|caplets|capsules)\b/i,
  money: /(?:[$£€])\s?\d[\d,]*(?:\.\d{2})?/,
  due: /\b(?:due(?: date)?|pay by|payment due)\b[\s:]*(.+)/i,
  date: /\b(?:[0-3]?\d[\/\-.][01]?\d[\/\-.]\d{2,4}|(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\.?\s+\d{1,2},?\s+\d{4})\b/i,
};
function fieldsFor(kind, lines) {
  const byText = lines.map((l) => l.text);
  const sorted = [...lines].filter((l) => l.conf >= 60 && (l.text.match(/[A-Za-z]/g) || []).length >= 3).sort((a, b) => b.size - a.size);
  const big = sorted.filter((l, i) => i === 0 || (i === 1 && l.size >= sorted[0].size * 0.8)).map((l) => l.text);
  const firstMatch = (rx, grp = 0) => { for (const t of byText) { const m = t.match(rx); if (m) return (m[grp] || m[0]).trim(); } return ""; };
  const linesMatching = (rx, n = 2) => byText.filter((t) => rx.test(t)).slice(0, n).join(" ");
  const f = [];
  const add = (label, value) => { if (value && value.trim()) f.push({ label, value: value.trim() }); };
  if (kind === "medicine") {
    add("Name (largest text)", big.join(" · ")); add("Strength", firstMatch(RX.strength)); add("Directions", linesMatching(RX.directions, 3));
    add("Warnings", linesMatching(RX.warning, 2)); add("Expiry", firstMatch(RX.expiry, 1));
    add("Amount in pack", (byText.find((t) => RX.size.test(t) && !RX.directions.test(t)) || "").match(RX.size)?.[0] || "");
  } else if (kind === "food") {
    add("Name (largest text)", big.join(" · ")); add("Size", firstMatch(RX.size)); add("Best before / use by", firstMatch(RX.expiry, 1));
    add("Allergens", firstMatch(RX.allergens, 2));
  } else if (kind === "mail") {
    add("Largest text", big.join(" · ")); add("Amount", firstMatch(RX.money)); add("Due", firstMatch(RX.due, 1)); add("Date", firstMatch(RX.date));
  } else if (kind === "book") {
    add("Title (largest text)", big.join(" · "));
  } else {
    add("Largest text", big.join(" · ")); add("Dates", firstMatch(RX.date)); add("Amount", firstMatch(RX.money));
  }
  return f;
}

async function read(opts = {}) {
  unlockSpeech();
  if (state.busy) return;
  if (!state.photo) { setResult("notfound", "Take a photo first.", "Point the camera at the text and take a photo."); say("Take a photo first."); return; }
  const kind = opts.kind || state.readKind;
  busy(true, "Reading…"); announce("Reading");
  try {
    let src = state.mid, region = null;
    if (opts.box) { const rc = regionCanvas(opts.box); src = rc.c; region = rc.r; }
    let lines = await ocrLines(src, 0, region);
    // zoom into each part of the photo so small print becomes readable
    if (!opts.box) {
      const regions = zoomGrid(false);
      for (let i = 0; i < regions.length; i++) {
        ui.verdict.textContent = `Reading… (zooming in, part ${i + 1} of ${regions.length})`;
        ui.where.textContent = "Looking closely at each part of the photo for small print.";
        mergeLines(lines, (await ocrLines(cropCanvas(regions[i], 1800, 3), 0, regions[i])).filter((l) => l.conf >= 60));
      }
    }
    if (kind === "book" || kind === "all" || opts.box) {
      ui.where.textContent = "Checking for sideways text…";
      for (const deg of [90, 270]) {
        const extra = (await ocrLines(src, deg, region)).filter((l) => l.conf >= 70 && l.text.length >= 3);
        mergeLines(lines, extra);
      }
    }
    lines = lines.filter((l) => l.conf >= 50);
    if (!lines.length) {
      setResult("notfound", "I can't find readable text in this photo.", "Get closer so the text fills most of the photo, use good light, and keep the phone steady.");
      say("I can't find readable text. Get closer, use good light, and try again.");
      return;
    }
    // reading order: top-to-bottom for upright lines, then sideways lines
    lines.sort((a, b) => (a.deg - b.deg) || (a.box[1] - b.box[1]) || (a.box[0] - b.box[0]));
    const fields = fieldsFor(kind, lines);
    const full = lines.map((l) => l.text).join("\n");
    const lowConf = lines.filter((l) => l.conf < 70).length;
    const summary = fields.length ? `${fields[0].value}.` : "Here is the text I could read.";
    setResult("found", summary, "", lowConf ? [["medium", "Some words may be misread"]] : [["plain", "Read on this device"]]);
    ui.fields.replaceChildren(...fields.flatMap((x) => { const dt = document.createElement("dt"); dt.textContent = x.label; const dd = document.createElement("dd"); dd.textContent = x.value; return [dt, dd]; }));
    ui.fields.hidden = !fields.length;
    ui.fulltext.textContent = full; ui.fullWrap.open = kind === "all" || kind === "book" || fields.length < 2;
    ui.readout.hidden = false;
    const spoken = fields.map((x) => `${x.label.replace(/ \(.*\)/, "")}: ${x.value}.`).join(" ");
    say(spoken + (kind === "all" || kind === "book" || !fields.length ? " " + full.slice(0, 1500) : "") + (lowConf ? " Some words may be misread." : ""));
  } catch (e) {
    console.error(e);
    setResult("error", "Something went wrong while reading.", "Try again. If it keeps happening, reload the app.");
    say("Something went wrong while reading.");
  } finally { busy(false); }
}

// ------------------------------------------------------------------ controls
function clearChips() { for (const c of ui.chips.querySelectorAll(".chip")) c.setAttribute("aria-pressed", "false"); }
ui.chips.onclick = (e) => {
  const b = e.target.closest(".chip"); if (!b) return;
  const on = b.getAttribute("aria-pressed") === "true"; clearChips();
  if (!on) { b.setAttribute("aria-pressed", "true"); state.item = b.dataset.item; ui.q.value = ""; if (state.photo) find(); } else state.item = "";
};
ui.q.oninput = () => { clearChips(); state.item = ""; };
ui.q.onkeydown = (e) => { if (e.key === "Enter") { e.preventDefault(); find(); } };
ui.find.onclick = find;
ui.readChips.onclick = (e) => {
  const b = e.target.closest(".chip"); if (!b) return;
  for (const c of ui.readChips.querySelectorAll(".chip")) c.setAttribute("aria-pressed", String(c === b));
  state.readKind = b.dataset.kind; if (state.photo) read();
};
ui.read.onclick = () => read();
ui.readLabel.onclick = () => {
  const w = state.lastWhat.toLowerCase();
  const kind = /medic|pill|tablet|tylenol|advil|aspirin|ibuprofen/.test(w) ? "medicine" : /book|novel/.test(w) ? "book" : /milk|food|can|cereal|juice|sauce|snack|jar/.test(w) ? "food" : "all";
  read({ box: state.lastBox, kind });
};
function setMode(m) {
  ui.tabFind.setAttribute("aria-selected", String(m === "find")); ui.tabRead.setAttribute("aria-selected", String(m === "read"));
  ui.findPanel.hidden = m !== "find"; ui.readPanel.hidden = m !== "read";
}
ui.tabFind.onclick = () => setMode("find");
ui.tabRead.onclick = () => setMode("read");

let size = Number(store.get("findit-size")) || 1.25;
const applySize = () => { document.documentElement.style.setProperty("--read-size", size + "rem"); store.set("findit-size", String(size)); };
ui.smaller.onclick = () => { size = Math.max(1, size - 0.25); applySize(); };
ui.bigger.onclick = () => { size = Math.min(3, size + 0.25); applySize(); };
applySize();

// ------------------------------------------------------------------ start
(function drawBlank() {
  ctx.fillStyle = getComputedStyle(document.body).backgroundColor; ctx.fillRect(0, 0, canvas.width, canvas.height);
})();
if ("serviceWorker" in navigator && location.protocol !== "file:") navigator.serviceWorker.register("sw.js").catch(() => {});
updateStatus();
getOCR().catch((e) => console.warn("OCR load failed", e));               // the text reader ships with the app
if (store.get("findit-model")) getDetector(false).catch(() => { store.set("findit-model", ""); ui.setup.hidden = false; updateStatus(); });
else ui.setup.hidden = false;
if (location.protocol === "file:") setResult("error", "Open FindIt through a web address.", "Double-click “Start FindIt” (see README), or host the folder online. Opening the file directly blocks the camera and the AI models.");

// test hook (used by the automated checks; harmless otherwise)
window.__findit = { usePhoto, find, read, parseQuery, describe, bestTextMatch, state, getOCR, binarize, reRead };
